package com.example.carromvisiontest

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * Starter prototype: demonstrates Android's user-consent screen for screen capture
 * and a separate, illustrative trajectory preview. It does not read game internals,
 * automate gameplay, or draw over another app.
 */
class MainActivity : Activity() {
    private lateinit var statusText: TextView
    private val requestCapture = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            setBackgroundColor(Color.rgb(245, 247, 250))
        }

        val title = TextView(this).apply {
            text = "Carrom Vision Test"
            textSize = 25f
            setTextColor(Color.rgb(23, 50, 77))
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(12))
        }
        root.addView(title)

        val intro = TextView(this).apply {
            text = "প্রাথমিক পরীক্ষামূলক সংস্করণ\n\nএখন আলাদা প্রিভিউতে একটি নমুনা গতিপথ দেখানো হয়। স্ক্রিন ক্যাপচার শুরু করার আগে Android আপনার অনুমতি চাইবে।"
            textSize = 16f
            setTextColor(Color.DKGRAY)
            setPadding(0, 0, 0, dp(12))
        }
        root.addView(intro)

        val preview = TrajectoryView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(300)
            ).apply { bottomMargin = dp(12) }
        }
        root.addView(preview)

        val captureButton = Button(this).apply {
            text = "স্ক্রিন ক্যাপচারের অনুমতি পরীক্ষা"
            setOnClickListener { askForCapturePermission() }
        }
        root.addView(captureButton)

        statusText = TextView(this).apply {
            text = "অবস্থা: এখনো ক্যাপচারের অনুমতি চাওয়া হয়নি।"
            textSize = 14f
            setTextColor(Color.rgb(40, 60, 75))
            setPadding(0, dp(12), 0, 0)
        }
        root.addView(statusText)

        val note = TextView(this).apply {
            text = "\nনোট: এই সংস্করণে আসল গুটি শনাক্তকরণ, লাইভ ক্যাপচার বিশ্লেষণ, AI মডেল বা অন্য অ্যাপের ওপর overlay এখনো যুক্ত নেই।"
            textSize = 13f
            setTextColor(Color.GRAY)
        }
        root.addView(note)

        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
    }

    private fun askForCapturePermission() {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(manager.createScreenCaptureIntent(), requestCapture)
    }

    @Deprecated("Uses the classic activity result callback for broad SDK compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestCapture) {
            statusText.text = if (resultCode == RESULT_OK && data != null) {
                "অনুমতি দেওয়া হয়েছে। এই প্রোটোটাইপে এখনো ক্যাপচার সার্ভিস চালু করা হয় না।"
            } else {
                "অনুমতি দেওয়া হয়নি। চাইলে পরে আবার চেষ্টা করুন।"
            }
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}

private class TrajectoryView(context: Context) : View(context) {
    private val boardPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(220, 190, 140)
        style = android.graphics.Paint.Style.FILL
    }
    private val borderPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(100, 65, 35)
        style = android.graphics.Paint.Style.STROKE
        strokeWidth = 7f
    }
    private val linePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(210, 45, 45)
        style = android.graphics.Paint.Style.STROKE
        strokeWidth = 5f
    }
    private val coinPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(30, 90, 180)
        style = android.graphics.Paint.Style.FILL
    }
    private val targetPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(35, 130, 75)
        style = android.graphics.Paint.Style.FILL
    }

    override fun onDraw(canvas: android.graphics.Canvas) {
        super.onDraw(canvas)
        val left = width * 0.06f
        val top = height * 0.06f
        val right = width * 0.94f
        val bottom = height * 0.94f
        canvas.drawRoundRect(left, top, right, bottom, 18f, 18f, boardPaint)
        canvas.drawRoundRect(left, top, right, bottom, 18f, 18f, borderPaint)
        val sx = width * 0.23f
        val sy = height * 0.72f
        val tx = width * 0.78f
        val ty = height * 0.28f
        canvas.drawLine(sx, sy, tx, ty, linePaint)
        canvas.drawCircle(sx, sy, 13f, coinPaint)
        canvas.drawCircle(tx, ty, 11f, targetPaint)
    }
}
